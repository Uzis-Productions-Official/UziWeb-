/**
 * UziWeb server (enhanced)
 * - Serves UI from /public
 * - Provides /proxy?url=<https://target> with light HTML rewrite:
 *   - strips X-Frame-Options / CSP headers
 *   - injects <base> so relative URLs resolve
 * - Demo only; add auth/rate limiting/allowlist before exposing.
 */
const express = require("express");
const morgan = require("morgan");
const compression = require("compression");
const { URL } = require("url");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(morgan("dev"));
app.use(compression());
app.use(express.static(path.join(__dirname, "public"), { fallthrough: true }));

function normalizeTarget(raw) {
  if (!raw) return null;
  try {
    if (!/^https?:\/\//i.test(raw)) raw = "https://" + raw;
    const u = new URL(raw);
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u;
  } catch { return null; }
}

app.get("/proxy", async (req, res) => {
  const targetRaw = req.query.url;
  const targetUrl = normalizeTarget(targetRaw);
  if (!targetUrl) return res.status(400).send("Bad request: provide ?url=https://example.com");

  try {
    const upstream = await fetch(targetUrl.toString(), {
      method: "GET",
      redirect: "follow",
      headers: {
        "user-agent": "Mozilla/5.0 (X11; CrOS x86_64) UziWeb/2.0",
        "accept":
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "accept-language": "en-US,en;q=0.9",
      },
    });

    res.status(upstream.status);
    upstream.headers.forEach((value, key) => {
      const k = key.toLowerCase();
      if (k === "x-frame-options" ||
          k === "content-security-policy" ||
          k === "content-security-policy-report-only" ||
          k === "strict-transport-security" ||
          k === "set-cookie") return; // drop
      res.setHeader(key, value);
    });
    res.setHeader("x-frame-options", "ALLOWALL");
    res.setHeader("access-control-allow-origin", "*");

    const ct = upstream.headers.get("content-type") || "";
    if (ct.includes("text/html")) {
      const html = await upstream.text();
      const baseHref = targetUrl.origin + targetUrl.pathname.replace(/[^\/]*$/, "");
      let transformed = html;
      if (/<head[^>]*>/i.test(html)) {
        transformed = html.replace(/<head([^>]*)>/i, `<head$1><base href="${baseHref}">`);
      } else {
        transformed = `<!doctype html><head><base href="${baseHref}"></head>` + html;
      }
      transformed = transformed.replace(
        /<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi,
        ""
      );
      res.setHeader("content-type", "text/html; charset=utf-8");
      res.send(transformed);
    } else {
      const reader = upstream.body.getReader();
      res.setHeader("content-type", ct || "application/octet-stream");
      function pump() {
        reader.read().then(({done, value}) => {
          if (done) { res.end(); return; }
          res.write(Buffer.from(value));
          pump();
        }).catch(err => { console.error("Stream error:", err); res.end(); });
      }
      pump();
    }
  } catch (err) {
    console.error("Proxy error:", err);
    res.status(502).send("Proxy error fetching the target URL.");
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`UziWeb running at http://localhost:${PORT}`);
});

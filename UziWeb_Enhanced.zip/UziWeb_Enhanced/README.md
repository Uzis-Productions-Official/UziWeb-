# UziWeb (Enhanced GX Edition)
Opera GX–style **vertical tabs**, fancy **theme switcher**, and a built‑in **proxy** to iframe more sites.

## Features
- Vertical **sidebar tabs** (add/close/switch)
- **New Tab Page** with logo, search + quick chips
- **Per-tab history** (Back/Forward/Reload)
- **Proxy toggle** (bypasses `X-Frame-Options`/CSP on many pages)
- **Theme switcher** button with animated swatches (Dark Purple, Neon Blue, Blood Red, Cyber Green, Classic Dark)

## Run (Node 18+ / Codespaces)
```bash
npm install
npm start
# open http://localhost:3000
```

## Notes
This is an educational proxy; before deploying publicly add an allowlist, auth and rate limiting.

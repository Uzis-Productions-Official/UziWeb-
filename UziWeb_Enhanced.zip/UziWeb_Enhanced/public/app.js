// UziWeb Enhanced — vertical tabs + theme switcher
const tabsEl = document.getElementById("tabs");
const newTabBtn = document.getElementById("newTabBtn");
const urlInput = document.getElementById("urlInput");
const goBtn = document.getElementById("goBtn");
const backBtn = document.getElementById("backBtn");
const forwardBtn = document.getElementById("forwardBtn");
const reloadBtn = document.getElementById("reloadBtn");
const proxyToggle = document.getElementById("proxyToggle");
const viewsEl = document.getElementById("tabViews");

const themeBtn = document.getElementById("themeBtn");
const themePanel = document.getElementById("themePanel");
const themeList = document.getElementById("themeList");
const closeTheme = document.getElementById("closeTheme");

const newTabTemplate = document.getElementById("newTabTemplate");

let tabs = [];
let activeTabId = null;
let themeData = null;

function uid(){ return Math.random().toString(36).slice(2,9); }

function toSearchUrl(q){
  const isUrl = /^(https?:\/\/|[a-z0-9\-]+\.[a-z]{2,})/i.test(q.trim());
  if (isUrl){
    let u = q.trim();
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    return u;
  }
  return "https://www.google.com/search?q=" + encodeURIComponent(q);
}

function createTab(){
  const id = uid();
  const tab = {
    id,
    title: "New Tab",
    icon: "🟣",
    history: [],
    index: -1,
    iframe: null,
    viewEl: null,
    homeEl: null
  };
  tabs.push(tab);

  // Sidebar button
  const container = document.createElement("div");
  container.className = "tab";
  container.dataset.id = id;

  const btn = document.createElement("button");
  btn.textContent = "🌐";
  btn.title = tab.title;
  btn.addEventListener("click", () => activateTab(id));

  const close = document.createElement("button");
  close.className = "close-btn";
  close.textContent = "×";
  close.title = "Close Tab";
  close.addEventListener("click", (e) => { e.stopPropagation(); closeTab(id); });

  container.appendChild(btn);
  container.appendChild(close);
  tabsEl.appendChild(container);

  // View container
  const view = document.createElement("div");
  view.className = "tab-view";
  view.dataset.id = id;

  const iframe = document.createElement("iframe");
  iframe.setAttribute("sandbox", "allow-scripts allow-forms allow-same-origin allow-popups");
  view.appendChild(iframe);

  // New tab page
  const tpl = newTabTemplate.content.cloneNode(true);
  const home = tpl.querySelector(".home");
  view.appendChild(home);

  // Search form on NTP
  const searchForm = view.querySelector(".search-form");
  const searchInput = view.querySelector(".search-input");
  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    navigate(id, searchInput.value);
  });
  view.querySelectorAll(".chip").forEach(ch => {
    ch.addEventListener("click", () => navigate(id, ch.dataset.url));
  });

  viewsEl.appendChild(view);

  // save references
  tab.iframe = iframe;
  tab.viewEl = view;
  tab.homeEl = home;

  activateTab(id);
  return id;
}

function closeTab(id){
  const idx = tabs.findIndex(t => t.id === id);
  if (idx === -1) return;
  const wasActive = activeTabId === id;

  // remove DOM
  const side = tabsEl.querySelector(`.tab[data-id="${id}"]`);
  if (side) side.remove();
  const view = viewsEl.querySelector(`.tab-view[data-id="${id}"]`);
  if (view) view.remove();

  tabs.splice(idx,1);

  if (wasActive){
    if (tabs[idx]) activateTab(tabs[idx].id);
    else if (tabs[idx-1]) activateTab(tabs[idx-1].id);
    else if (tabs[0]) activateTab(tabs[0].id);
    else activeTabId = null;
  }
  updateNavButtons();
}

function activateTab(id){
  activeTabId = id;
  // sidebar active state
  tabsEl.querySelectorAll(".tab").forEach(el => {
    el.classList.toggle("active", el.dataset.id === id);
  });
  // view active state
  viewsEl.querySelectorAll(".tab-view").forEach(el => {
    el.classList.toggle("active", el.dataset.id === id);
  });
  const tab = getTab(id);
  if (!tab) return;
  // Update omnibar with current URL text
  const raw = currentRaw(tab);
  urlInput.value = raw || "";
  updateNavButtons();
}

function getTab(id){ return tabs.find(t => t.id === id); }

function currentRaw(tab){
  if (tab.index >= 0) return tab.history[tab.index];
  return null;
}

function updateNavButtons(){
  const tab = getTab(activeTabId);
  if (!tab) {
    backBtn.disabled = true; forwardBtn.disabled = true;
    return;
  }
  backBtn.disabled = tab.index <= 0;
  forwardBtn.disabled = tab.index >= tab.history.length - 1;
}

function navigate(id, raw){
  const tab = getTab(id);
  if (!tab) return;
  const direct = toSearchUrl(raw);
  const useProxy = proxyToggle.checked;
  const finalSrc = useProxy ? `/proxy?url=${encodeURIComponent(direct)}` : direct;

  // push into tab history
  if (tab.index === -1 || tab.history[tab.index] !== raw){
    tab.history.splice(tab.index + 1);
    tab.history.push(raw);
    tab.index = tab.history.length - 1;
  }

  // show iframe, hide home
  tab.homeEl.style.display = "none";
  tab.iframe.style.display = "block";

  tab.iframe.src = finalSrc;
  tab.title = raw;
  urlInput.value = raw;

  // update sidebar icon/title tooltip
  const side = tabsEl.querySelector(`.tab[data-id="${id}"] > button`);
  if (side) side.title = raw;

  if (id === activeTabId) updateNavButtons();
}

function go(raw){
  if (!activeTabId) createTab();
  navigate(activeTabId, raw);
}

// Controls
goBtn.addEventListener("click", () => go(urlInput.value));
urlInput.addEventListener("keydown", (e) => { if (e.key === "Enter") go(urlInput.value) });

backBtn.addEventListener("click", () => {
  const tab = getTab(activeTabId);
  if (!tab || tab.index <= 0) return;
  tab.index--;
  navigate(tab.id, tab.history[tab.index]);
});
forwardBtn.addEventListener("click", () => {
  const tab = getTab(activeTabId);
  if (!tab || tab.index >= tab.history.length - 1) return;
  tab.index++;
  navigate(tab.id, tab.history[tab.index]);
});
reloadBtn.addEventListener("click", () => {
  const tab = getTab(activeTabId);
  if (!tab) return;
  const raw = currentRaw(tab);
  if (raw) navigate(tab.id, raw);
});

newTabBtn.addEventListener("click", () => createTab());

// Theme switcher
async function loadThemes(){
  const res = await fetch("./themes.json");
  themeData = await res.json();
  renderThemeList();
  const saved = localStorage.getItem("uzi_theme_key") || "darkPurple";
  applyTheme(saved);
}
function renderThemeList(){
  themeList.innerHTML = "";
  Object.entries(themeData).forEach(([key, t]) => {
    const card = document.createElement("div");
    card.className = "theme-card";
    // swatch inherits current CSS --acc/--acc2; override inline for preview
    const swatch = document.createElement("div");
    swatch.className = "swatch";
    swatch.style.setProperty("--acc", t.vars["--acc"]);
    swatch.style.setProperty("--acc2", t.vars["--acc2"]);
    const name = document.createElement("div");
    name.className = "theme-name";
    name.textContent = t.name;
    card.appendChild(swatch);
    card.appendChild(name);
    card.addEventListener("click", () => { applyTheme(key); themePanel.classList.remove("open"); });
    themeList.appendChild(card);
  });
}
function applyTheme(key){
  const t = themeData[key];
  if (!t) return;
  Object.entries(t.vars).forEach(([k,v]) => document.documentElement.style.setProperty(k, v));
  localStorage.setItem("uzi_theme_key", key);
}

// Theme panel interactions
themeBtn.addEventListener("click", () => themePanel.classList.toggle("open"));
closeTheme.addEventListener("click", () => themePanel.classList.remove("open"));
document.addEventListener("click", (e) => {
  if (!themePanel.contains(e.target) && e.target !== themeBtn){
    themePanel.classList.remove("open");
  }
});

// Initialize with one tab
createTab();
loadThemes();

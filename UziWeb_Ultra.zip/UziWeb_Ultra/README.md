# UziWeb Ultra (GX Edition)
Features:
- Enhanced proxy with `<base>` injection + CSP/XFO stripping + domain injector + ad-block list
- Download Manager (paste URL → download MP4/MP3 via backend, progress + save/open)
- Music player with MP3 uploads (`/upload`), playlist, shuffle, loop
- Tabs: favicons, close, drag & drop reorder, live preview via proxy
- Session restore (reopen tabs on next start)
- Split-screen mode inside a tab (two frames)
- Incognito toggle (per-tab; skips session/history)
- History viewer with timestamps
- Themes panel (dark variants)
- Voice command (Web Speech API), notifications
- Screenshot (proxy-only fallback exports page HTML)

## Run
```bash
npm install
npm start
# open http://localhost:3000
```

> Note: Some features (screenshots, previews) rely on "Proxy" being enabled.

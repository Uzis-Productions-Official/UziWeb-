/**
 * UziWeb Ultra server
 * - Static UI in /public
 * - Improved /proxy with HTML base injection + CSP stripping + optional injector script
 * - /download streams any file (video/mp4, audio/mpeg) with content-disposition
 * - /upload MP3 for music player
 * - /injector.js serves user CSS/JS to proxied pages
 * - Simple ad-block host denylist
 *
 * ⚠ For educational use. Add authentication/limits before internet exposure.
 */
const express = require("express");
const compression = require("compression");
const morgan = require("morgan");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

// --- config ---
const AD_BLOCK = new Set([
  // minimal sample list; extend as needed
  "doubleclick.net","googlesyndication.com","adservice.google.com",
  "ads.twitter.com","ads.facebook.com","adroll.com","taboola.com","outbrain.com"
]);

// Middleware
app.use(morgan("dev"));
app.use(compression());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Basic CORS for local usage
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

// ===== Uploads (MP3) =====
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, "uploads")),
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^\w\-.]+/g, "_");
    cb(null, Date.now() + "_" + safe);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "audio/mpeg" || file.mimetype === "audio/mp3") cb(null, true);
    else cb(new Error("Only MP3 files allowed"));
  }
});
app.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file" });
  return res.json({ ok: true, name: req.file.originalname, url: `/uploads/${req.file.filename}` });
});

// ===== Helper =====
function normalizeUrl(raw) {
  try {
    if (!/^https?:\/\//i.test(raw)) raw = "https://" + raw;
    const u = new URL(raw);
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u;
  } catch { return null; }
}

// ===== Injector =====
// Frontend will POST a small map of domain-> { css, js } and we cache in memory for demo
let USER_INJECT = {};
app.post("/api/inject/save", (req,res)=>{
  USER_INJECT = req.body || {};
  res.json({ ok: true });
});

app.get("/injector.js", (req,res)=>{
  const raw = req.query.u || "";
  let domain = "";
  try { domain = new URL(raw).hostname; } catch {}
  const rule = USER_INJECT[domain] || USER_INJECT["*"] || { css:"", js:"" };
  const js = `
  (function(){
    try{
      if (${JSON.stringify(rule.css)}){
        const st = document.createElement('style');
        st.textContent = ${JSON.stringify(rule.css)};
        document.documentElement.appendChild(st);
      }
      if (${JSON.stringify(rule.js)}){
        const s = document.createElement('script');
        s.textContent = ${JSON.stringify(rule.js)};
        document.documentElement.appendChild(s);
      }
      console.log("UziWeb injector applied for", ${JSON.stringify(domain)});
    }catch(e){}
  })();`;
  res.setHeader("content-type","application/javascript; charset=utf-8");
  res.send(js);
});

// ===== Proxy =====
app.get("/proxy", async (req, res) => {
  const targetRaw = req.query.url;
  const target = normalizeUrl(targetRaw);
  if (!target) return res.status(400).send("Bad request: ?url=https://example.com");

  // Ad/malware block (simple)
  if (AD_BLOCK.has(target.hostname)) {
    return res.status(451).send("Blocked by UziWeb ad filter");
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    const upstream = await fetch(target.toString(), {
      method: "GET",
      redirect: "follow",
      signal: controller.signal,
      headers: {
        "user-agent": "Mozilla/5.0 (X11; CrOS x86_64) UziWebUltra/4.0",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "accept-language": "en-US,en;q=0.9"
      }
    });
    clearTimeout(timeout);

    res.status(upstream.status);

    upstream.headers.forEach((value, key) => {
      const k = key.toLowerCase();
      if (k === "x-frame-options" ||
          k === "content-security-policy" ||
          k === "content-security-policy-report-only" ||
          k === "strict-transport-security" ||
          k === "set-cookie") return;
      res.setHeader(key, value);
    });
    res.setHeader("x-frame-options", "ALLOWALL");
    res.setHeader("access-control-allow-origin", "*");

    const ct = upstream.headers.get("content-type") || "";
    if (ct.includes("text/html")) {
      const html = await upstream.text();
      const baseHref = target.origin + target.pathname.replace(/[^\/]*$/, "");
      let transformed = html;

      if (/<head[^>]*>/i.test(transformed)) {
        transformed = transformed.replace(/<head([^>]*)>/i,
          `<head$1><base href="${baseHref}"><script defer src="/injector.js?u=${encodeURIComponent(target.toString())}"></script>`);
      } else {
        transformed = `<!doctype html><head><base href="${baseHref}"><script defer src="/injector.js?u=${encodeURIComponent(target.toString())}"></script></head>` + transformed;
      }

      // Remove CSP meta tags
      transformed = transformed.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, "");

      res.setHeader("content-type", "text/html; charset=utf-8");
      return res.send(transformed);
    }

    // Stream other types
    const reader = upstream.body.getReader();
    const contentType = ct || "application/octet-stream";
    res.setHeader("content-type", contentType);

    function pump() {
      reader.read().then(({done, value}) => {
        if (done) { res.end(); return; }
        res.write(Buffer.from(value));
        pump();
      }).catch(err => { console.error("Stream error:", err); res.end(); });
    }
    pump();
  } catch (err) {
    console.error("Proxy error:", err);
    res.status(502).send("Proxy error: " + (err && err.message ? err.message : "unknown"));
  }
});

// ===== Download =====
app.get("/download", async (req, res) => {
  const target = normalizeUrl(req.query.url || "");
  if (!target) return res.status(400).send("Bad request");
  try {
    const up = await fetch(target.toString(), {
      redirect: "follow",
      headers: { "user-agent": "Mozilla/5.0 UziWebUltra/4.0" }
    });
    const ct = up.headers.get("content-type") || "application/octet-stream";
    const nameGuess = decodeURIComponent((target.pathname.split("/").pop() || "file")).replace(/[^\w\-.]+/g,"_");
    const filename = nameGuess || (ct.includes("mp4") ? "video.mp4" : ct.includes("mpeg") ? "audio.mp3" : "file.bin");

    res.setHeader("content-type", ct);
    res.setHeader("content-disposition", `attachment; filename="${filename}"`);
    res.status(up.status);
    up.body.pipe(res);
  } catch(e) {
    res.status(502).send("Download failed: " + e.message);
  }
});

// Fallback to SPA
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`🚀 UziWeb Ultra running at http://localhost:${PORT}`);
});

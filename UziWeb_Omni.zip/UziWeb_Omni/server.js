/**
 * UziWeb Omni server
 * Adds:
 * - Uzi Searched mini-engine: /api/search/crawl, /api/search/query, /uzi-search UI
 * - Persistent downloads saved under /downloads + listing endpoint
 * - Settings (proxy allowlist) persisted in /data/settings.json
 * - Improvements to proxy & injector; small fixes
 */
const express = require("express");
const compression = require("compression");
const morgan = require("morgan");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

// Paths
const DATA = path.join(__dirname, "data");
const UPLOADS = path.join(__dirname, "uploads");
const DL = path.join(__dirname, "downloads");
fs.mkdirSync(DATA, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });
fs.mkdirSync(DL, { recursive: true });

// Basic JSON helpers
const settingsPath = path.join(DATA, "settings.json");
function readJSON(p, d){ try{ return JSON.parse(fs.readFileSync(p, "utf8")); } catch{ return d; } }
function writeJSON(p, v){ fs.writeFileSync(p, JSON.stringify(v, null, 2)); }

// Default settings
const settings = readJSON(settingsPath, { proxyAllowlist: ["*"] }); // "*" means all, else array of hostnames

// Middleware
app.use(morgan("dev"));
app.use(compression());
app.use(express.json({ limit:"1mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(UPLOADS));
app.use("/downloads", express.static(DL));

// CORS for local
app.use((req,res,next)=>{
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

// ---- Settings API ----
app.get("/api/settings", (req,res)=> res.json(settings));
app.post("/api/settings", (req,res)=>{
  const body = req.body || {};
  if (Array.isArray(body.proxyAllowlist)){
    settings.proxyAllowlist = body.proxyAllowlist;
    writeJSON(settingsPath, settings);
  }
  res.json({ ok:true, settings });
});

// ---- Upload MP3 ----
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS),
  filename: (req, file, cb) => {
    const safe = (file.originalname||"file").replace(/[^\w\-.]+/g,"_");
    cb(null, Date.now()+"_"+safe);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 100*1024*1024 },
  fileFilter: (req, file, cb)=>{
    if ((file.mimetype||"").includes("audio")) cb(null, true);
    else cb(new Error("Only audio files allowed"));
  }
});
app.post("/upload", upload.single("file"), (req,res)=>{
  if (!req.file) return res.status(400).json({ error:"No file" });
  res.json({ ok:true, name:req.file.originalname, url: `/uploads/${req.file.filename}` });
});

// ---- Helper ----
function normalizeUrl(raw){
  try{
    if (!/^https?:\/\//i.test(raw)) raw = "https://" + raw;
    const u = new URL(raw);
    if (!["http:","https:"].includes(u.protocol)) return null;
    return u;
  }catch{ return null; }
}
function inAllowlist(host){
  const list = settings.proxyAllowlist || ["*"];
  if (list.includes("*")) return true;
  return list.includes(host);
}

// ---- Injector ----
let USER_INJECT = {};
app.post("/api/inject/save", (req,res)=>{ USER_INJECT = req.body || {}; res.json({ ok:true }); });
app.get("/injector.js", (req,res)=>{
  const raw = req.query.u || "";
  let domain = ""; try { domain = new URL(raw).hostname; } catch {}
  const rule = USER_INJECT[domain] || USER_INJECT["*"] || { css:"", js:"" };
  const js = `
    (function(){
      try{
        ${rule.css ? `var st=document.createElement('style'); st.textContent=${JSON.stringify(rule.css)}; document.documentElement.appendChild(st);` : ""}
        ${rule.js ? `var s=document.createElement('script'); s.textContent=${JSON.stringify(rule.js)}; document.documentElement.appendChild(s);` : ""}
      }catch(e){}
    })();`;
  res.setHeader("content-type","application/javascript; charset=utf-8");
  res.send(js);
});

// ---- Proxy ----
app.get("/proxy", async (req,res)=>{
  const target = normalizeUrl(req.query.url||"");
  if (!target) return res.status(400).send("Bad request");
  if (!inAllowlist(target.hostname)) return res.status(451).send("Blocked by allowlist");

  try{
    const controller = new AbortController();
    const timeout = setTimeout(()=>controller.abort(), 30000);

    const upstream = await fetch(target.toString(), {
      redirect: "follow",
      signal: controller.signal,
      headers: {
        "user-agent": "Mozilla/5.0 (X11; CrOS) UziWebOmni/5.0",
        "accept": "*/*"
      }
    });
    clearTimeout(timeout);

    res.status(upstream.status);
    upstream.headers.forEach((v,k)=>{
      const key = k.toLowerCase();
      if (["x-frame-options","content-security-policy","content-security-policy-report-only","strict-transport-security","set-cookie"].includes(key)) return;
      res.setHeader(k, v);
    });
    res.setHeader("x-frame-options","ALLOWALL");
    res.setHeader("access-control-allow-origin","*");

    const ct = upstream.headers.get("content-type") || "";
    if (ct.includes("text/html")){
      const html = await upstream.text();
      const baseHref = target.origin + target.pathname.replace(/[^\/]*$/, "");
      let transformed = html.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, "");
      if (/<head[^>]*>/i.test(transformed)){
        transformed = transformed.replace(/<head([^>]*)>/i, `<head$1><base href="${baseHref}"><script defer src="/injector.js?u=${encodeURIComponent(target.toString())}"></script>`);
      } else {
        transformed = `<!doctype html><head><base href="${baseHref}"><script defer src="/injector.js?u=${encodeURIComponent(target.toString())}"></script></head>` + transformed;
      }
      res.setHeader("content-type","text/html; charset=utf-8");
      return res.send(transformed);
    } else {
      res.setHeader("content-type", ct || "application/octet-stream");
      upstream.body.pipe(res);
    }
  }catch(e){
    res.status(502).send("Proxy error: " + e.message);
  }
});

// ---- Downloads (persistent) ----
app.get("/download", async (req,res)=>{
  const target = normalizeUrl(req.query.url||"");
  if (!target) return res.status(400).send("Bad request");
  try {
    const up = await fetch(target.toString(), { redirect: "follow", headers: { "user-agent": "Mozilla/5.0 UziWebOmni/5.0" } });
    const ct = up.headers.get("content-type") || "application/octet-stream";
    const fname = decodeURIComponent((target.pathname.split("/").pop()||"file")).replace(/[^\w\-.]+/g,"_") || "file.bin";
    const dest = path.join(DL, Date.now()+"_"+fname);
    const ws = fs.createWriteStream(dest);
    await new Promise((resolve, reject)=>{ up.body.pipe(ws); up.body.on("error", reject); ws.on("finish", resolve); });
    res.setHeader("content-type", "application/json");
    res.end(JSON.stringify({ ok:true, filename: path.basename(dest), url: `/downloads/${path.basename(dest)}`, contentType: ct }));
  } catch(e){
    res.status(502).json({ ok:false, error:e.message });
  }
});
app.get("/api/downloads", (req,res)=>{
  const files = fs.readdirSync(DL).sort().reverse().slice(0,200).map(n=>({ name:n, url:`/downloads/${n}` }));
  res.json(files);
});

// ---- Uzi Searched: mini crawler + index ----
// index structure: { pages: {url: {title, text}}, inv: {term: {url: tf}}, df: {term: docCount} }
const indexPath = path.join(DATA, "index.json");
let IDX = readJSON(indexPath, { pages: {}, inv: {}, df: {} });

function tokenize(text){
  return (text.toLowerCase().replace(/[^a-z0-9\s]+/g," ").split(/\s+/).filter(Boolean));
}

function addToIndex(url, title, text){
  IDX.pages[url] = { title, text: text.slice(0, 200000) };
  const terms = tokenize(title + " " + text);
  const tf = {};
  terms.forEach(t => tf[t] = (tf[t]||0)+1);
  Object.entries(tf).forEach(([term, freq]) => {
    if (!IDX.inv[term]) IDX.inv[term] = {};
    IDX.inv[term][url] = freq;
  });
  // document frequency
  Object.keys(tf).forEach(term => { IDX.df[term] = (IDX.df[term]||0)+1; });
}

async function robotsAllows(u){
  try{
    const robotsUrl = `${u.origin}/robots.txt`;
    const r = await fetch(robotsUrl, { headers: { "user-agent":"UziWebBot/0.1" } });
    if (!r.ok) return true;
    const txt = await r.text();
    // very naive: disallow lines for User-agent: * only
    const lines = txt.split(/\r?\n/);
    let active = false, allowed = true;
    for (const line of lines){
      const m = line.match(/^\s*User-agent:\s*(.+)/i);
      if (m){ active = (m[1].trim() === "*" || /uziwebbot/i.test(m[1])); continue; }
      if (!active) continue;
      const d = line.match(/^\s*Disallow:\s*(.*)/i);
      if (d){
        const rule = d[1].trim() || "/";
        if (u.pathname.startsWith(rule)) { allowed = false; break; }
      }
    }
    return allowed;
  }catch{ return true; }
}

function extractLinks(html, base){
  const rel = /<a\s[^>]*href=["']?([^"'>\s]+)["']?[^>]*>/gi;
  const out = new Set();
  let m;
  while ((m = rel.exec(html))){
    try{
      const href = m[1];
      const abs = new URL(href, base).toString();
      if (abs.startsWith("http")) out.add(abs);
    }catch{}
  }
  return [...out];
}
function stripHtml(html){
  return html.replace(/<script[\s\S]*?<\/script>/gi," ")
             .replace(/<style[\s\S]*?<\/style>/gi," ")
             .replace(/<[^>]+>/g," ");
}

app.post("/api/search/crawl", async (req,res)=>{
  const { seeds = [], maxPages = 20, sameOrigin = false } = req.body || {};
  const visited = new Set();
  const queue = [];
  seeds.slice(0,5).forEach(s => { try{ const u = new URL(/^https?:\/\//.test(s)?s:"https://"+s); queue.push(u.toString()); }catch{} });

  while (queue.length && visited.size < Math.min(200, maxPages)){
    const url = queue.shift();
    if (visited.has(url)) continue;
    visited.add(url);
    let u; try { u = new URL(url); } catch { continue; }
    if (!(await robotsAllows(u))) continue;

    try{
      const r = await fetch(url, { redirect: "follow", headers: { "user-agent":"UziWebBot/0.1" } });
      if (!r.ok) continue;
      const ct = r.headers.get("content-type") || "";
      if (!ct.includes("text/html")) continue;
      const html = await r.text();
      const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1] || url;
      const text = stripHtml(html);
      addToIndex(url, title, text);
      const links = extractLinks(html, url).slice(0, 50);
      for (const L of links){
        if (visited.has(L)) continue;
        if (sameOrigin && new URL(L).origin !== u.origin) continue;
        queue.push(L);
      }
    }catch{}
  }
  writeJSON(indexPath, IDX);
  res.json({ ok:true, pages: Object.keys(IDX.pages).length });
});

app.get("/api/search/index", (req,res)=>{
  res.json({ pages: Object.keys(IDX.pages).length, terms: Object.keys(IDX.inv).length });
});

app.get("/api/search/query", (req,res)=>{
  const q = String(req.query.q||"").trim().toLowerCase();
  if (!q) return res.json([]);
  const terms = tokenize(q);
  const scores = new Map();
  const N = Math.max(1, Object.keys(IDX.pages).length);
  for (const term of terms){
    const postings = IDX.inv[term] || {};
    const df = IDX.df[term] || 1;
    const idf = Math.log(N / df);
    Object.entries(postings).forEach(([url, tf])=>{
      scores.set(url, (scores.get(url)||0) + tf * idf);
    });
  }
  const ranked = [...scores.entries()].sort((a,b)=> b[1]-a[1]).slice(0, 50).map(([url, score])=>{
    const p = IDX.pages[url] || { title:url, text:"" };
    const snippet = p.text.slice(0, 160).replace(/\s+/g," ").trim();
    return { url, title: p.title, snippet, score: +score.toFixed(3) };
  });
  res.json(ranked);
});

// Fallback SPA
app.get("*", (req,res)=> res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, ()=> console.log(`🚀 UziWeb Omni at http://localhost:${PORT}`));

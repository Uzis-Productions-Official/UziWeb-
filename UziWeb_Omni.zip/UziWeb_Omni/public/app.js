// UziWeb Omni front-end
const el = id=>document.getElementById(id);
const tabsEl = el("tabs"), viewsEl = el("tabViews");
const newTabBtn = el("newTabBtn");
const urlInput = el("urlInput"), engineSel = el("engine"), goBtn = el("goBtn");
const backBtn = el("backBtn"), forwardBtn = el("forwardBtn"), reloadBtn = el("reloadBtn");
const incognitoToggle = el("incognitoToggle"), proxyToggle = el("proxyToggle");
const loader = el("loader"), statusEl = el("status");
const shotBtn = el("shotBtn"), splitBtn = el("splitBtn"), lockBtn = el("lockBtn");

const bookmarksBtn = el("bookmarksBtn"), bookmarksPanel = el("bookmarksPanel");
const bookmarksList = el("bookmarksList"), closeBookmarks = el("closeBookmarks"), bookmarkThis = el("bookmarkThis");

const musicBtn = el("musicBtn"), musicPanel = el("musicPanel"), closeMusic = el("closeMusic");
const player = el("player"), nowPlaying = el("nowPlaying");
const prevBtn = el("prevBtn"), playBtn = el("playBtn"), nextBtn = el("nextBtn");
const vol = el("vol"), loop = el("loop"), shuffle = el("shuffle"), uploadInput = el("upload"), uploadBtn = el("uploadBtn");
const playlistEl = el("playlist");

const downloadsBtn = el("downloadsBtn"), downloadsPanel = el("downloadsPanel"), closeDownloads = el("closeDownloads");
const dlUrl = el("dlUrl"), dlBtn = el("dlBtn"), dlList = el("dlList");

const historyBtn = el("historyBtn"), historyPanel = el("historyPanel"), historyList = el("historyList"), closeHistory = el("closeHistory");
const settingsBtn = el("settingsBtn"), settingsPanel = el("settingsPanel"), closeSettings = el("closeSettings");
const allowlistInput = el("allowlistInput"), saveAllowlist = el("saveAllowlist");

const voiceBtn = el("voiceBtn"), notifyBtn = el("notifyBtn");
const newTabTemplate = document.getElementById("newTabTemplate");

let tabs = [], activeTabId = null;
let historyStore = JSON.parse(localStorage.getItem("uzi_history") || "[]");
let bookmarks = JSON.parse(localStorage.getItem("uzi_bookmarks") || "[]");
let playlist = JSON.parse(localStorage.getItem("uzi_playlist") || "[]");
let trackIndex = parseInt(localStorage.getItem("uzi_track_index") || "0",10);
let speedDial = JSON.parse(localStorage.getItem("uzi_speed_dial") || "[]");
let lockedTabs = {}; // id -> { locked: true, pass: '...' }

function uid(){ return Math.random().toString(36).slice(2,9); }
function engineUrl(engine, q){
  const qs = encodeURIComponent(q);
  if (engine === "uzi") return `/uzi-search.html?q=${qs}`;
  if (engine === "duck") return `https://duckduckgo.com/?q=${qs}`;
  if (engine === "bing") return `https://www.bing.com/search?q=${qs}`;
  if (engine === "brave") return `https://search.brave.com/search?q=${qs}`;
  return `https://www.google.com/search?q=${qs}`;
}
function toSearchOrUrl(q){
  const isUrl = /^(https?:\/\/|[a-z0-9\-.]+\.[a-z]{2,})(\/.*)?$/i.test(q.trim());
  if (isUrl){ let u=q.trim(); if (!/^https?:\/\//i.test(u)) u = "https://" + u; return u; }
  return engineUrl(engineSel.value, q);
}
function faviconFor(url){ return `https://www.google.com/s2/favicons?sz=64&domain_url=${encodeURIComponent(url)}`; }
function saveSession(){ localStorage.setItem("uzi_session_tabs", JSON.stringify(tabs.filter(t=>!t.incognito).map(t=>({ raw: currentRaw(t), split: t.split })))); }
function currentRaw(t){ return t.index>=0 ? t.history[t.index] : null; }
function getTab(id){ return tabs.find(t=>t.id===id); }

// Tabs
function createTab(opts={}){
  const id = uid();
  const tab = { id, title:"New Tab", history:[], index:-1, incognito: !!opts.incognito, split:false, iframeA:null, iframeB:null, viewEl:null, homeEl:null };
  tabs.push(tab);

  const container = document.createElement("div"); container.className="tab"; container.dataset.id=id; container.draggable = true;
  const btn = document.createElement("button"); btn.className="tab-btn"; const img = document.createElement("img"); img.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Crect width='16' height='16' rx='4' fill='%23c084fc'/%3E%3C/svg%3E"; btn.appendChild(img);
  btn.addEventListener("click", ()=> activateTab(id));
  const preview = document.createElement("div"); preview.className="preview"; const pv = document.createElement("iframe"); preview.appendChild(pv);
  btn.addEventListener("mouseenter", ()=>{ const raw = currentRaw(tab); if (!raw) return; pv.src = `/proxy?url=${encodeURIComponent(toSearchOrUrl(raw))}`; });
  const close = document.createElement("button"); close.className="close-btn"; close.textContent="✕"; close.addEventListener("click",(e)=>{ e.stopPropagation(); closeTab(id); });
  container.appendChild(btn); container.appendChild(close); container.appendChild(preview); tabsEl.appendChild(container);

  container.addEventListener("dragstart",(e)=> e.dataTransfer.setData("text/plain", id));
  tabsEl.addEventListener("dragover",(e)=> e.preventDefault());
  tabsEl.addEventListener("drop",(e)=>{ e.preventDefault(); const draggedId = e.dataTransfer.getData("text/plain"); const target = e.target.closest(".tab"); if (!target || draggedId===target.dataset.id) return; const draggedEl = tabsEl.querySelector(`.tab[data-id="${draggedId}"]`); tabsEl.insertBefore(draggedEl, target); const order=[...tabsEl.querySelectorAll(".tab")].map(el=>el.dataset.id); tabs.sort((a,b)=> order.indexOf(a.id)-order.indexOf(b.id)); saveSession(); });

  // View
  const view = document.createElement("div"); view.className="tab-view"; view.dataset.id=id;
  const frames = document.createElement("div"); frames.className="frames";
  const a = document.createElement("div"); a.className="frame-wrap"; const ia = document.createElement("iframe"); ia.setAttribute("sandbox","allow-scripts allow-forms allow-same-origin allow-popups"); a.appendChild(ia); frames.appendChild(a);
  const home = newTabTemplate.content.cloneNode(true).querySelector(".home");
  view.appendChild(frames); view.appendChild(home); viewsEl.appendChild(view);
  // speed dial render
  const dial = home.querySelector("#speedDial"); dial.innerHTML=""; (speedDial.length?speedDial:[
    "https://google.com","https://youtube.com","https://github.com","https://developer.mozilla.org","https://news.ycombinator.com"
  ]).forEach(u=>{ const b=document.createElement("button"); b.className="chip"; b.textContent=new URL(u).hostname.replace("www.",""); b.addEventListener("click",()=>navigate(id,u)); dial.appendChild(b); });
  const addUrl = home.querySelector("#addDialUrl"); const addBtn = home.querySelector("#addDialBtn"); addBtn.addEventListener("click",()=>{ if (addUrl.value.trim()){ try{ const abs = toSearchOrUrl(addUrl.value.trim()); speedDial = Array.from(new Set([...(speedDial||[]), abs])); localStorage.setItem("uzi_speed_dial", JSON.stringify(speedDial)); addUrl.value=""; dial.appendChild(Object.assign(document.createElement("button"), { className:"chip", textContent:new URL(abs).hostname.replace("www.","") })); }catch{} }});
  const searchForm = home.querySelector(".search-form"), searchInput = home.querySelector(".search-input");
  searchForm.addEventListener("submit",(e)=>{ e.preventDefault(); navigate(id, searchInput.value); });

  tab.iframeA = ia; tab.viewEl = view; tab.homeEl = home;
  activateTab(id);
  return id;
}

function closeTab(id){
  const idx = tabs.findIndex(t=>t.id===id); if (idx===-1) return;
  const wasActive = (activeTabId===id);
  tabsEl.querySelector(`.tab[data-id="${id}"]`)?.remove();
  viewsEl.querySelector(`.tab-view[data-id="${id}"]`)?.remove();
  tabs.splice(idx,1); delete lockedTabs[id];
  if (wasActive){ const next = tabs[idx] || tabs[idx-1] || tabs[0]; if (next) activateTab(next.id); else activeTabId=null; }
  saveSession();
}

function activateTab(id){
  activeTabId = id;
  tabsEl.querySelectorAll(".tab-btn").forEach(el=> el.classList.toggle("active", el.parentElement.dataset.id===id));
  viewsEl.querySelectorAll(".tab-view").forEach(el=> el.classList.toggle("active", el.dataset.id===id));
  const t = getTab(id); if (!t) return;
  urlInput.value = currentRaw(t) || "";
  incognitoToggle.checked = !!t.incognito;
  splitBtn.classList.toggle("active", !!t.split);
  updateNavButtons();
}

function updateNavButtons(){
  const t = getTab(activeTabId);
  backBtn.disabled = !t || t.index<=0;
  forwardBtn.disabled = !t || t.index>=t.history.length-1;
}

function buildSrc(raw){
  const direct = toSearchOrUrl(raw);
  return proxyToggle.checked ? `/proxy?url=${encodeURIComponent(direct)}` : direct;
}

function navigate(id, raw, { replace=false } = {}){
  const t = getTab(id); if (!t) return;
  if (lockedTabs[id]?.locked){ const ok = prompt("This tab is locked. Enter password to navigate:"); if (ok !== lockedTabs[id].pass) { alert("Wrong password"); return; } }

  if (!replace){
    if (t.index===-1 || t.history[t.index]!==raw){ t.history.splice(t.index+1); t.history.push(raw); t.index = t.history.length-1; }
  }
  t.homeEl.style.display = "none";
  t.viewEl.classList.toggle("split", !!t.split);

  const src = buildSrc(raw);
  loader.classList.remove("hidden"); statusEl.textContent="Loading…";
  const done=()=>{ loader.classList.add("hidden"); statusEl.textContent="Done"; };
  const err = ()=>{ loader.classList.add("hidden"); statusEl.textContent="Error"; };

  t.iframeA.onload = done; t.iframeA.onerror = err; t.iframeA.src = src;
  tabsEl.querySelector(`.tab[data-id="${id}"] img`).src = faviconFor(src);
  urlInput.value = raw;

  if (!t.incognito){ historyStore.unshift({ url: toSearchOrUrl(raw), ts: Date.now() }); historyStore = historyStore.slice(0,700); localStorage.setItem("uzi_history", JSON.stringify(historyStore)); saveSession(); }
  updateNavButtons();
}

function go(raw){ if (!activeTabId) createTab({ incognito: incognitoToggle.checked }); navigate(activeTabId, raw); }

// Controls
goBtn.addEventListener("click", ()=> go(urlInput.value));
urlInput.addEventListener("keydown", (e)=>{ if (e.key==="Enter") go(urlInput.value) });
backBtn.addEventListener("click", ()=>{ const t=getTab(activeTabId); if (t && t.index>0){ t.index--; navigate(t.id, t.history[t.index], { replace:true }); }});
forwardBtn.addEventListener("click", ()=>{ const t=getTab(activeTabId); if (t && t.index < t.history.length-1){ t.index++; navigate(t.id, t.history[t.index], { replace:true }); }});
reloadBtn.addEventListener("click", ()=>{ const t=getTab(activeTabId); if (t){ const raw = currentRaw(t); if (raw) navigate(t.id, raw, { replace:true }); }});
newTabBtn.addEventListener("click", ()=> createTab({ incognito: incognitoToggle.checked }));
incognitoToggle.addEventListener("change", ()=>{ const t=getTab(activeTabId); if (t) t.incognito = incognitoToggle.checked; });

// Split-screen
splitBtn.addEventListener("click", ()=>{
  const t=getTab(activeTabId); if (!t) return;
  t.split = !t.split; t.viewEl.classList.toggle("split", t.split);
  if (t.split && currentRaw(t)){
    if (!t.iframeB){
      t.iframeB = document.createElement("iframe");
      t.iframeB.setAttribute("sandbox","allow-scripts allow-forms allow-same-origin allow-popups");
      const wrap = document.createElement("div"); wrap.className="frame-wrap"; wrap.appendChild(t.iframeB);
      t.viewEl.querySelector(".frames").appendChild(wrap);
    } else if (!t.iframeB.parentElement){
      const wrap = document.createElement("div"); wrap.className="frame-wrap"; wrap.appendChild(t.iframeB);
      t.viewEl.querySelector(".frames").appendChild(wrap);
    }
    t.iframeB.src = buildSrc(t.history[t.index]);
  } else {
    if (t.iframeB){ t.iframeB.src="about:blank"; t.iframeB.parentElement?.remove(); }
  }
  saveSession();
});

// Lock tab
lockBtn.addEventListener("click", ()=>{
  const id = activeTabId; if (!id) return;
  if (lockedTabs[id]?.locked){ const pass = prompt("Unlock tab: enter password"); if (pass===lockedTabs[id].pass){ lockedTabs[id]={locked:false, pass:null}; alert("Unlocked"); } else alert("Wrong password"); return; }
  const p = prompt("Set password for this tab"); if (p){ lockedTabs[id]={ locked:true, pass:p }; alert("Locked"); }
});

// Screenshot (save HTML)
shotBtn.addEventListener("click", async ()=>{
  if (!proxyToggle.checked){ alert("Enable Proxy for page save."); return; }
  const t=getTab(activeTabId); if (!t) return; const raw = currentRaw(t); if (!raw) return;
  const resp = await fetch(`/proxy?url=${encodeURIComponent(toSearchOrUrl(raw))}`);
  const html = await resp.text(); const blob = new Blob([html], { type:"text/html" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "page.html"; a.click();
});

// Bookmarks
function renderBookmarks(){
  bookmarksList.innerHTML = "";
  if (!bookmarks.length){ const empty=document.createElement("div"); empty.style.color="#aaa"; empty.textContent="No bookmarks."; bookmarksList.appendChild(empty); return; }
  bookmarks.forEach(b=>{
    const item = document.createElement("div"); item.className="item";
    const icon = new Image(); icon.src = faviconFor(b.url); icon.width=20; icon.height=20; icon.style.borderRadius="4px";
    const title = document.createElement("div"); title.textContent = b.title || b.url;
    const open = document.createElement("button"); open.textContent="Open"; open.addEventListener("click", ()=>{ if (!activeTabId) createTab(); navigate(activeTabId, b.url); bookmarksPanel.classList.add("hidden"); });
    const del = document.createElement("button"); del.textContent="Delete"; del.addEventListener("click", ()=>{ bookmarks = bookmarks.filter(x=>x.url!==b.url); localStorage.setItem("uzi_bookmarks", JSON.stringify(bookmarks)); renderBookmarks(); });
    item.appendChild(icon); item.appendChild(title); item.appendChild(open); item.appendChild(del); bookmarksList.appendChild(item);
  });
}
bookmarksBtn.addEventListener("click", ()=>{ bookmarksPanel.classList.toggle("hidden"); renderBookmarks(); });
closeBookmarks.addEventListener("click", ()=> bookmarksPanel.classList.add("hidden"));
bookmarkThis.addEventListener("click", ()=>{
  const t=getTab(activeTabId); if (!t) return; const raw=currentRaw(t); if (!raw) return;
  bookmarks = bookmarks.filter(x=>x.url!==raw); bookmarks.unshift({ url: toSearchOrUrl(raw), title: raw });
  localStorage.setItem("uzi_bookmarks", JSON.stringify(bookmarks)); renderBookmarks();
});

// Downloads (persistent list)
async function refreshDownloads(){
  const list = await fetch("/api/downloads").then(r=>r.json());
  dlList.innerHTML=""; list.forEach(f=>{
    const item = document.createElement("div"); item.className="item";
    const name = document.createElement("div"); name.textContent = f.name;
    const open = document.createElement("a"); open.textContent="Open"; open.href = f.url; open.target="_blank"; open.className="button";
    item.appendChild(name); item.appendChild(open); dlList.appendChild(item);
  });
}
downloadsBtn.addEventListener("click", ()=>{ downloadsPanel.classList.toggle("hidden"); refreshDownloads(); });
closeDownloads.addEventListener("click", ()=> downloadsPanel.classList.add("hidden"));
dlBtn.addEventListener("click", async ()=>{
  const v = dlUrl.value.trim(); if (!v) return;
  const r = await fetch(`/download?url=${encodeURIComponent(v)}`).then(r=>r.json()).catch(()=>null);
  if (r && r.ok){ await refreshDownloads(); new Notification?.("UziWeb", { body:"Download completed" }); } else alert("Download failed");
});

// History
function renderHistory(){
  historyList.innerHTML = "";
  historyStore.forEach(h=>{
    const item=document.createElement("div"); item.className="item";
    const icon = new Image(); icon.src=faviconFor(h.url); icon.width=20; icon.height=20; icon.style.borderRadius="4px";
    const title=document.createElement("div"); title.textContent = `${new Date(h.ts).toLocaleString()} — ${h.url}`;
    const open=document.createElement("button"); open.textContent="Open"; open.addEventListener("click", ()=>{ if (!activeTabId) createTab(); navigate(activeTabId, h.url); historyPanel.classList.add("hidden"); });
    item.appendChild(icon); item.appendChild(title); item.appendChild(open); historyList.appendChild(item);
  });
}
historyBtn.addEventListener("click", ()=>{ historyPanel.classList.toggle("hidden"); renderHistory(); });
closeHistory.addEventListener("click", ()=> historyPanel.classList.add("hidden"));

// Music
function renderPlaylist(){
  playlistEl.innerHTML=""; if (!playlist.length){ const empty=document.createElement("div"); empty.style.color="#aaa"; empty.textContent="No tracks yet."; playlistEl.appendChild(empty); return; }
  playlist.forEach((p,i)=>{
    const item=document.createElement("div"); item.className="item";
    const meta=document.createElement("div"); const t=document.createElement("div"); t.textContent=p.name||`Track ${i+1}`; const u=document.createElement("div"); u.style.color="#aaa"; u.textContent=p.url; meta.appendChild(t); meta.appendChild(u);
    const play=document.createElement("button"); play.textContent="Play"; play.addEventListener("click", ()=> playTrack(i));
    const remove=document.createElement("button"); remove.textContent="Remove"; remove.addEventListener("click", ()=>{ playlist.splice(i,1); localStorage.setItem("uzi_playlist", JSON.stringify(playlist)); if (trackIndex>=playlist.length) trackIndex=0; renderPlaylist(); });
    item.appendChild(meta); item.appendChild(play); item.appendChild(remove); playlistEl.appendChild(item);
  });
}
function playTrack(i){
  if (!playlist.length) return;
  trackIndex = (i+playlist.length)%playlist.length;
  const track = playlist[trackIndex];
  player.src = track.url; player.play().catch(()=>{}); nowPlaying.textContent = `♫ ${track.name||track.url}`;
  localStorage.setItem("uzi_track_index", String(trackIndex)); playBtn.textContent="⏸";
}
playBtn.addEventListener("click", ()=>{ if (player.paused){ player.play().catch(()=>{}); playBtn.textContent="⏸"; } else { player.pause(); playBtn.textContent="▶"; } });
prevBtn.addEventListener("click", ()=> playTrack(trackIndex-1));
nextBtn.addEventListener("click", ()=>{ if (shuffle.checked){ playTrack(Math.floor(Math.random()*playlist.length)); } else playTrack(trackIndex+1); });
vol.addEventListener("input", ()=> player.volume = parseFloat(vol.value));
loop.addEventListener("change", ()=> player.loop = loop.checked);
player.addEventListener("ended", ()=>{ if (!player.loop) nextBtn.click(); });
uploadBtn.addEventListener("click", async ()=>{
  const file = uploadInput.files?.[0]; if (!file) return;
  const fd = new FormData(); fd.append("file", file);
  try { const res = await fetch("/upload", { method:"POST", body: fd }).then(r=>r.json());
    if (res.ok){ playlist.push({ name: res.name, url: res.url }); localStorage.setItem("uzi_playlist", JSON.stringify(playlist)); renderPlaylist(); playTrack(playlist.length-1); } else alert("Upload failed");
  } catch(e){ alert("Upload error"); }
});
musicBtn.addEventListener("click", ()=>{ musicPanel.classList.toggle("hidden"); renderPlaylist(); });
closeMusic.addEventListener("click", ()=> musicPanel.classList.add("hidden"));

// Voice + Notifications
voiceBtn.addEventListener("click", ()=>{
  try{ const SR = window.SpeechRecognition || window.webkitSpeechRecognition; const rec = new SR(); rec.lang="en-US"; rec.onresult=(e)=>{ const t=e.results[0][0].transcript; statusEl.textContent = "Heard: " + t; go(t); }; rec.start(); }catch{ alert("Speech recognition not supported."); }
});
notifyBtn.addEventListener("click", async ()=>{ if (Notification.permission!=="granted"){ await Notification.requestPermission(); } if (Notification.permission==="granted"){ new Notification("UziWeb",{ body:"Hi from UziWeb Omni" }); } });

// Settings
async function loadSettings(){
  const s = await fetch("/api/settings").then(r=>r.json());
  allowlistInput.value = (s.proxyAllowlist||["*"]).join(", ");
}
saveAllowlist.addEventListener("click", async ()=>{
  const list = allowlistInput.value.split(",").map(s=>s.trim()).filter(Boolean);
  const res = await fetch("/api/settings", { method:"POST", headers:{"content-type":"application/json"}, body: JSON.stringify({ proxyAllowlist: list })}).then(r=>r.json());
  alert("Saved allowlist");
});
settingsBtn.addEventListener("click", ()=>{ settingsPanel.classList.toggle("hidden"); });
closeSettings.addEventListener("click", ()=> settingsPanel.classList.add("hidden"));

// Panels toggles
bookmarksBtn.addEventListener("click", ()=>{ bookmarksPanel.classList.toggle("hidden"); renderBookmarks(); });
closeBookmarks.addEventListener("click", ()=> bookmarksPanel.classList.add("hidden"));

// Session restore
function restoreSession(){
  const data = JSON.parse(localStorage.getItem("uzi_session_tabs") || "[]");
  if (data.length){ data.forEach(t=>{ const id=createTab(); if (t.split) getTab(id).split=true; if (t.raw) navigate(id, t.raw); }); }
  else createTab();
}
window.addEventListener("beforeunload", saveSession);

// Init
(async function init(){
  await loadSettings();
  renderPlaylist();
  restoreSession();
})();

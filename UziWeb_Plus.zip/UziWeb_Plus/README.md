# UziWeb Plus (GX Edition)
- Vertical tabs (favicons), closable + draggable
- Fancy themes panel
- New Tab page with search + chips
- Per-tab history, back/forward/reload
- **Bookmarks** panel + "Bookmark this" button
- **Music Player** panel with MP3 upload (stored in `/uploads`), playlist, shuffle/loop
- **Improved Proxy** with `<base>` injection & CSP meta stripping, streaming for non-HTML

## Run
```bash
npm install
npm start
# open http://localhost:3000
```

> Demo proxy is for research/education. Add auth/allowlist/rate-limits before deploying.

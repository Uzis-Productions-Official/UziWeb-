/**
 * UziWeb Plus server
 * - Static UI in /public
 * - Improved /proxy with HTML base injection and CSP/meta stripping
 * - Streams non-HTML content
 * - Simple uploads for MP3s at /upload (stored in /uploads) + served from /uploads
 * - DO NOT expose publicly without auth/allowlisting
 */
const express = require("express");
const compression = require("compression");
const morgan = require("morgan");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(morgan("dev"));
app.use(compression());
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Basic CORS for local usage
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

// ===== Uploads (MP3) =====
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, "uploads")),
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^\w\-.]+/g, "_");
    cb(null, Date.now() + "_" + safe);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "audio/mpeg" || file.mimetype === "audio/mp3") cb(null, true);
    else cb(new Error("Only MP3 files allowed"));
  }
});

app.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file" });
  return res.json({
    ok: true,
    name: req.file.originalname,
    url: `/uploads/${req.file.filename}`
  });
});

// ===== Improved Proxy =====
function toUrl(raw) {
  try {
    if (!/^https?:\/\//i.test(raw)) raw = "https://" + raw;
    const u = new URL(raw);
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u;
  } catch { return null; }
}

app.get("/proxy", async (req, res) => {
  const targetRaw = req.query.url;
  const target = toUrl(targetRaw);
  if (!target) return res.status(400).send("Bad request: ?url=https://example.com");

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    const upstream = await fetch(target.toString(), {
      method: "GET",
      redirect: "follow",
      signal: controller.signal,
      headers: {
        "user-agent": "Mozilla/5.0 (X11; CrOS x86_64) UziWebPlus/3.0",
        "accept":
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "accept-language": "en-US,en;q=0.9"
      }
    });
    clearTimeout(timeout);

    // Pass through status
    res.status(upstream.status);

    // Copy headers with sanitization
    upstream.headers.forEach((value, key) => {
      const k = key.toLowerCase();
      if (k === "x-frame-options" ||
          k === "content-security-policy" ||
          k === "content-security-policy-report-only" ||
          k === "strict-transport-security" ||
          k === "set-cookie") return;
      res.setHeader(key, value);
    });
    res.setHeader("x-frame-options", "ALLOWALL");
    res.setHeader("access-control-allow-origin", "*");

    const ct = upstream.headers.get("content-type") || "";
    if (ct.includes("text/html")) {
      const html = await upstream.text();
      const baseHref = target.origin + target.pathname.replace(/[^\/]*$/, "");
      let transformed = html;

      // Inject <base> into <head> to resolve relative paths
      if (/<head[^>]*>/i.test(transformed)) {
        transformed = transformed.replace(/<head([^>]*)>/i, `<head$1><base href="${baseHref}">`);
      } else {
        transformed = `<!doctype html><head><base href="${baseHref}"></head>` + transformed;
      }

      // Drop CSP meta tags
      transformed = transformed.replace(
        /<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi,
        ""
      );
      res.setHeader("content-type", "text/html; charset=utf-8");
      return res.send(transformed);
    }

    // Stream other types
    const reader = upstream.body.getReader();
    const contentType = ct || "application/octet-stream";
    res.setHeader("content-type", contentType);

    function pump() {
      reader.read().then(({done, value}) => {
        if (done) { res.end(); return; }
        res.write(Buffer.from(value));
        pump();
      }).catch(err => { console.error("Stream error:", err); res.end(); });
    }
    pump();
  } catch (err) {
    console.error("Proxy error:", err);
    res.status(502).send("Proxy error: " + (err && err.message ? err.message : "unknown"));
  }
});

// Fallback to SPA
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`🚀 UziWeb Plus running at http://localhost:${PORT}`);
});

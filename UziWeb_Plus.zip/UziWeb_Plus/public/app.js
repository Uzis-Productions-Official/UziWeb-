// UziWeb Plus front-end
const tabsEl = document.getElementById("tabs");
const newTabBtn = document.getElementById("newTabBtn");
const urlInput = document.getElementById("urlInput");
const goBtn = document.getElementById("goBtn");
const backBtn = document.getElementById("backBtn");
const forwardBtn = document.getElementById("forwardBtn");
const reloadBtn = document.getElementById("reloadBtn");
const proxyToggle = document.getElementById("proxyToggle");
const viewsEl = document.getElementById("tabViews");
const loader = document.getElementById("loader");
const statusEl = document.getElementById("status");

// Panels & theme
const themeBtn = document.getElementById("themeBtn");
const themePanel = document.getElementById("themePanel");
const themeList = document.getElementById("themeList");
const closeTheme = document.getElementById("closeTheme");

const bookmarksBtn = document.getElementById("bookmarksBtn");
const bookmarksPanel = document.getElementById("bookmarksPanel");
const bookmarksList = document.getElementById("bookmarksList");
const closeBookmarks = document.getElementById("closeBookmarks");
const bookmarkThis = document.getElementById("bookmarkThis");

const musicBtn = document.getElementById("musicBtn");
const musicPanel = document.getElementById("musicPanel");
const closeMusic = document.getElementById("closeMusic");
const player = document.getElementById("player");
const nowPlaying = document.getElementById("nowPlaying");
const prevBtn = document.getElementById("prevBtn");
const playBtn = document.getElementById("playBtn");
const nextBtn = document.getElementById("nextBtn");
const vol = document.getElementById("vol");
const loop = document.getElementById("loop");
const shuffle = document.getElementById("shuffle");
const uploadInput = document.getElementById("upload");
const uploadBtn = document.getElementById("uploadBtn");
const playlistEl = document.getElementById("playlist");

const newTabTemplate = document.getElementById("newTabTemplate");

// State
let tabs = [];
let activeTabId = null;
let themeData = null;

let bookmarks = JSON.parse(localStorage.getItem("uzi_bookmarks") || "[]");

let playlist = JSON.parse(localStorage.getItem("uzi_playlist") || "[]");
let trackIndex = parseInt(localStorage.getItem("uzi_track_index") || "0", 10);

// Utils
function uid(){ return Math.random().toString(36).slice(2,9); }
function toSearchUrl(q){
  const isUrl = /^(https?:\/\/|[a-z0-9\-.]+\.[a-z]{2,})/i.test(q.trim());
  if (isUrl){
    let u = q.trim();
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    return u;
  }
  return "https://www.google.com/search?q=" + encodeURIComponent(q);
}
function faviconFor(url){
  return `https://www.google.com/s2/favicons?sz=64&domain_url=${encodeURIComponent(url)}`;
}

// Tabs
function createTab(){
  const id = uid();
  const tab = {
    id, title: "New Tab", icon: "🌐", history: [], index: -1, iframe: null, viewEl: null, homeEl: null
  };
  tabs.push(tab);

  // Sidebar item
  const container = document.createElement("div");
  container.className = "tab";
  container.dataset.id = id;
  container.draggable = true;

  const btn = document.createElement("button");
  btn.className = "tab-btn";
  const img = document.createElement("img");
  img.alt = "tab";
  img.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Ccircle cx='8' cy='8' r='7' fill='%23c084fc'/%3E%3C/svg%3E";
  btn.appendChild(img);
  btn.addEventListener("click", () => activateTab(id));

  const close = document.createElement("button");
  close.className = "close-btn";
  close.textContent = "✕";
  close.title = "Close Tab";
  close.addEventListener("click", (e) => { e.stopPropagation(); closeTab(id); });

  container.appendChild(btn);
  container.appendChild(close);
  tabsEl.appendChild(container);

  // Drag & drop reorder
  container.addEventListener("dragstart", (e)=>{ e.dataTransfer.setData("text/plain", id); });
  tabsEl.addEventListener("dragover", (e)=> e.preventDefault());
  tabsEl.addEventListener("drop", (e)=> {
    e.preventDefault();
    const draggedId = e.dataTransfer.getData("text/plain");
    const target = e.target.closest(".tab");
    if (!target || draggedId === target.dataset.id) return;
    const draggedEl = tabsEl.querySelector(`.tab[data-id="${draggedId}"]`);
    tabsEl.insertBefore(draggedEl, target);
    // reorder array
    const order = [...tabsEl.querySelectorAll(".tab")].map(el => el.dataset.id);
    tabs.sort((a,b)=> order.indexOf(a.id) - order.indexOf(b.id));
  });

  // View
  const view = document.createElement("div");
  view.className = "tab-view";
  view.dataset.id = id;

  const iframe = document.createElement("iframe");
  iframe.setAttribute("sandbox", "allow-scripts allow-forms allow-same-origin allow-popups");
  view.appendChild(iframe);

  // Home
  const tpl = newTabTemplate.content.cloneNode(true);
  const home = tpl.querySelector(".home");
  view.appendChild(home);

  // Home interactions
  const searchForm = view.querySelector(".search-form");
  const searchInput = view.querySelector(".search-input");
  searchForm.addEventListener("submit", (e) => { e.preventDefault(); navigate(id, searchInput.value); });
  view.querySelectorAll(".chip").forEach(ch => ch.addEventListener("click", () => navigate(id, ch.dataset.url)));

  viewsEl.appendChild(view);

  tab.iframe = iframe; tab.viewEl = view; tab.homeEl = home;
  activateTab(id);
  return id;
}

function closeTab(id){
  const idx = tabs.findIndex(t => t.id === id);
  if (idx === -1) return;
  const wasActive = activeTabId === id;

  tabsEl.querySelector(`.tab[data-id="${id}"]`)?.remove();
  viewsEl.querySelector(`.tab-view[data-id="${id}"]`)?.remove();
  tabs.splice(idx,1);

  if (wasActive){
    const next = tabs[idx] || tabs[idx-1] || tabs[0];
    if (next) activateTab(next.id); else activeTabId = null;
  }
  updateNavButtons();
}

function activateTab(id){
  activeTabId = id;
  tabsEl.querySelectorAll(".tab-btn").forEach(el => el.classList.toggle("active", el.parentElement.dataset.id === id));
  viewsEl.querySelectorAll(".tab-view").forEach(el => el.classList.toggle("active", el.dataset.id === id));
  const tab = getTab(id);
  const raw = currentRaw(tab);
  urlInput.value = raw || "";
  updateNavButtons();
}

function getTab(id){ return tabs.find(t => t.id === id); }
function currentRaw(tab){ return tab.index >= 0 ? tab.history[tab.index] : null; }

function updateNavButtons(){
  const tab = getTab(activeTabId);
  backBtn.disabled = !tab || tab.index <= 0;
  forwardBtn.disabled = !tab || tab.index >= tab.history.length - 1;
}

function navigate(id, raw){
  const tab = getTab(id); if (!tab) return;
  const direct = toSearchUrl(raw);
  const useProxy = proxyToggle.checked;
  const finalSrc = useProxy ? `/proxy?url=${encodeURIComponent(direct)}` : direct;

  // history
  if (tab.index === -1 || tab.history[tab.index] !== raw){
    tab.history.splice(tab.index + 1);
    tab.history.push(raw);
    tab.index = tab.history.length - 1;
  }

  tab.homeEl.style.display = "none";
  tab.iframe.style.display = "block";

  loader.classList.remove("hidden");
  statusEl.textContent = "Loading…";

  tab.iframe.onload = () => {
    loader.classList.add("hidden");
    statusEl.textContent = "Done";
  };
  tab.iframe.onerror = () => {
    statusEl.textContent = "Error loading";
    loader.classList.add("hidden");
  };

  tab.iframe.src = finalSrc;
  tab.title = raw;
  urlInput.value = raw;

  // update favicon
  const img = tabsEl.querySelector(`.tab[data-id="${id}"] img`);
  img.src = faviconFor(direct);

  updateNavButtons();
}

function go(raw){
  if (!activeTabId) createTab();
  navigate(activeTabId, raw);
}

// Controls
goBtn.addEventListener("click", () => go(urlInput.value));
urlInput.addEventListener("keydown", (e) => { if (e.key === "Enter") go(urlInput.value) });
backBtn.addEventListener("click", () => { const t = getTab(activeTabId); if (t && t.index > 0) { t.index--; navigate(t.id, t.history[t.index]); } });
forwardBtn.addEventListener("click", () => { const t = getTab(activeTabId); if (t && t.index < t.history.length - 1) { t.index++; navigate(t.id, t.history[t.index]); } });
reloadBtn.addEventListener("click", () => { const t = getTab(activeTabId); if (t) { const raw = currentRaw(t); if (raw) navigate(t.id, raw); }});
newTabBtn.addEventListener("click", () => createTab());

// Theme
async function loadThemes(){
  const res = await fetch("./themes.json");
  themeData = await res.json();
  renderThemeList();
  const saved = localStorage.getItem("uzi_theme_key") || "darkPurple";
  applyTheme(saved);
}
function renderThemeList(){
  themeList.innerHTML = "";
  Object.entries(themeData).forEach(([key, t]) => {
    const card = document.createElement("div");
    card.className = "theme-card";
    const swatch = document.createElement("div");
    swatch.className = "swatch";
    swatch.style.setProperty("--acc", t.vars["--acc"]);
    swatch.style.setProperty("--acc2", t.vars["--acc2"]);
    const name = document.createElement("div");
    name.className = "theme-name";
    name.textContent = t.name;
    card.appendChild(swatch); card.appendChild(name);
    card.addEventListener("click", () => { applyTheme(key); themePanel.classList.remove("open"); });
    themeList.appendChild(card);
  });
}
function applyTheme(key){
  const t = themeData[key]; if (!t) return;
  Object.entries(t.vars).forEach(([k,v]) => document.documentElement.style.setProperty(k, v));
  localStorage.setItem("uzi_theme_key", key);
}
themeBtn.addEventListener("click", () => themePanel.classList.toggle("open"));
closeTheme.addEventListener("click", () => themePanel.classList.remove("open"));
document.addEventListener("click", (e) => { if (!themePanel.contains(e.target) && e.target !== themeBtn) themePanel.classList.remove("open"); });

// Bookmarks
function renderBookmarks(){
  bookmarksList.innerHTML = "";
  if (!bookmarks.length){
    const empty = document.createElement("div");
    empty.style.color = "#aaa";
    empty.textContent = "No bookmarks yet.";
    bookmarksList.appendChild(empty);
    return;
  }
  bookmarks.forEach(b => {
    const item = document.createElement("div");
    item.className = "item";
    const icon = document.createElement("img");
    icon.src = faviconFor(b.url);
    icon.width = 20; icon.height = 20; icon.style.borderRadius = "4px";
    const title = document.createElement("div");
    title.textContent = b.title || b.url;
    const open = document.createElement("button");
    open.textContent = "Open";
    open.addEventListener("click", () => {
      if (!activeTabId) createTab();
      navigate(activeTabId, b.url);
      bookmarksPanel.classList.add("hidden");
    });
    const del = document.createElement("button");
    del.textContent = "Delete";
    del.addEventListener("click", () => {
      bookmarks = bookmarks.filter(x => x.url !== b.url);
      localStorage.setItem("uzi_bookmarks", JSON.stringify(bookmarks));
      renderBookmarks();
    });
    item.appendChild(icon); item.appendChild(title); item.appendChild(open); item.appendChild(del);
    bookmarksList.appendChild(item);
  });
}
bookmarksBtn.addEventListener("click", () => { bookmarksPanel.classList.toggle("hidden"); renderBookmarks(); });
closeBookmarks.addEventListener("click", () => bookmarksPanel.classList.add("hidden"));
bookmarkThis.addEventListener("click", () => {
  const t = getTab(activeTabId); if (!t) return;
  const raw = currentRaw(t); if (!raw) return;
  bookmarks = bookmarks.filter(x => x.url !== raw);
  bookmarks.unshift({ url: toSearchUrl(raw), title: raw });
  localStorage.setItem("uzi_bookmarks", JSON.stringify(bookmarks));
  renderBookmarks();
});

// Music Player
function renderPlaylist(){
  playlistEl.innerHTML = "";
  if (!playlist.length){
    const empty = document.createElement("div");
    empty.style.color = "#aaa";
    empty.textContent = "No tracks yet. Upload an MP3.";
    playlistEl.appendChild(empty);
    return;
  }
  playlist.forEach((p, i) => {
    const item = document.createElement("div");
    item.className = "item";
    const meta = document.createElement("div");
    meta.className = "meta";
    const t = document.createElement("div");
    t.textContent = p.name || `Track ${i+1}`;
    const u = document.createElement("div");
    u.style.color = "#aaa"; u.textContent = p.url;
    meta.appendChild(t); meta.appendChild(u);
    const play = document.createElement("button");
    play.textContent = "Play";
    play.addEventListener("click", () => playTrack(i));
    const remove = document.createElement("button");
    remove.textContent = "Remove";
    remove.addEventListener("click", () => {
      playlist.splice(i,1);
      localStorage.setItem("uzi_playlist", JSON.stringify(playlist));
      if (trackIndex >= playlist.length) trackIndex = 0;
      renderPlaylist();
    });
    item.appendChild(meta); item.appendChild(play); item.appendChild(remove);
    playlistEl.appendChild(item);
  });
}
function playTrack(i){
  if (!playlist.length) return;
  trackIndex = (i + playlist.length) % playlist.length;
  const track = playlist[trackIndex];
  player.src = track.url;
  player.play().catch(()=>{});
  nowPlaying.textContent = `♫ ${track.name || track.url}`;
  localStorage.setItem("uzi_track_index", String(trackIndex));
  playBtn.textContent = "⏸";
}
playBtn.addEventListener("click", () => {
  if (player.paused) { player.play().catch(()=>{}); playBtn.textContent = "⏸"; }
  else { player.pause(); playBtn.textContent = "▶"; }
});
prevBtn.addEventListener("click", () => playTrack(trackIndex - 1));
nextBtn.addEventListener("click", () => {
  if (shuffle.checked){
    playTrack(Math.floor(Math.random() * playlist.length));
  } else playTrack(trackIndex + 1);
});
vol.addEventListener("input", () => { player.volume = parseFloat(vol.value); });
loop.addEventListener("change", () => { player.loop = loop.checked; });
player.addEventListener("ended", () => { if (!player.loop) nextBtn.click(); });

uploadBtn.addEventListener("click", async () => {
  const file = uploadInput.files?.[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  try {
    const res = await fetch("/upload", { method: "POST", body: fd });
    const data = await res.json();
    if (data.ok){
      playlist.push({ name: data.name, url: data.url });
      localStorage.setItem("uzi_playlist", JSON.stringify(playlist));
      renderPlaylist();
      playTrack(playlist.length - 1);
    } else {
      alert("Upload failed");
    }
  } catch (e) {
    alert("Upload error");
  }
});

musicBtn.addEventListener("click", () => { musicPanel.classList.toggle("hidden"); renderPlaylist(); });
closeMusic.addEventListener("click", () => musicPanel.classList.add("hidden"));

// Init
createTab();
loadThemes();
renderBookmarks();
renderPlaylist();
